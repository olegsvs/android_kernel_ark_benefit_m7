#ifndef __LOGGER_CUSTOM_H
#define __LOGGER_CUSTOM_H

#include <generated/autoconf.h>

#define __MAIN_BUF_SIZE 32*1024 
#define __EVENTS_BUF_SIZE 64*1024 
#define __RADIO_BUF_SIZE 32*1024 
#define __SYSTEM_BUF_SIZE 32*1024

#endif /* __LOGGER_CUSTOM_H */


